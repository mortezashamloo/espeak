#!/usr/bin/env python3
"""Builds the eSpeak 1.48.15 SAPI5 engine (espeak_sapi.dll) with Visual C++ on Windows.

    python tools/sapi/build_sapi.py --arch x64      (or --arch x86)
    python tools/sapi/build_sapi.py --arch x64 --dry-run   (prepare sources, print commands)

Output: build-out/sapi/espeak_sapi-<arch>.dll

What it does: copies platforms/windows/windows_sapi, drops the 1.48.15 sources from src/ into it
(keeping the project's own speech.h / StdAfx.h), applies the small fixes listed in PATCHES below,
then runs cl / rc / link from a Visual Studio developer environment. No precompiled headers.
Needs: Visual Studio 2017+ (or Build Tools) with the C++ workload, ATL and a Windows 10/11 SDK.
"""
import argparse
import glob
import os
import re
import shutil
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
SAPI_SRC = os.path.join(ROOT, "platforms", "windows", "windows_sapi")

# espeak library sources compiled into the engine (same list as the original ttseng.dsp)
LIB_SOURCES = ["compiledict", "dictionary", "intonation", "klatt", "numbers", "phonemelist",
               "readclause", "setlengths", "sonic", "speak_lib", "synth_mbrola", "synthdata",
               "synthesize", "tr_languages", "translate", "voices", "wavegen"]
ENGINE_SOURCES = ["ttseng", "ttsengobj"]
# Windows-specific files of the project that must not be overwritten by src/ copies
KEEP_WINDOWS = {"speech.h", "stdafx.h", "stdint.h"}


def log(msg):
    print("[build_sapi] " + msg, flush=True)


def read(path):
    with open(path, "r", encoding="latin-1", newline="") as f:
        return f.read()


def write(path, text):
    with open(path, "w", encoding="latin-1", newline="") as f:
        f.write(text)


def patch(path, old, new, count=1):
    s = read(path)
    if old not in s:
        raise SystemExit("patch target not found in %s: %r" % (path, old))
    write(path, s.replace(old, new, count))
    log("patched %s" % os.path.relpath(path, ROOT))


def prepare(build_dir):
    """Create build_dir with the SAPI project + 1.48.15 sources and apply the fixes."""
    if os.path.isdir(build_dir):
        shutil.rmtree(build_dir)
    shutil.copytree(SAPI_SRC, build_dir)
    src_dir = os.path.join(build_dir, "src")
    os.makedirs(src_dir, exist_ok=True)
    n = 0
    for f in sorted(glob.glob(os.path.join(ROOT, "src", "*"))):
        name = os.path.basename(f)
        if name.lower() in KEEP_WINDOWS or not os.path.isfile(f):
            continue
        shutil.copy2(f, os.path.join(src_dir, name))
        n += 1
    log("copied %d files from src/" % n)

    # PATCH 1: the project's stdint.h is a VC6 stand-in; modern Visual C++ has <stdint.h>
    stale = os.path.join(src_dir, "stdint.h")
    if os.path.exists(stale):
        os.remove(stale)
    # PATCH 2: speech.h (Windows version) uses uint64_t for long64 on 64-bit builds
    patch(os.path.join(src_dir, "speech.h"), "#define SPEECH_H", "#define SPEECH_H\n#include <stdint.h>")
    # PATCH 3: Visual C++ defines _WIN64, not __WIN64__; build_sapi passes /D__WIN64__ for x64.
    # PATCH 4: ATL needs a newer minimum Windows version than the 0x0400 in the old stdafx.h
    patch(os.path.join(build_dir, "stdafx.h"), "#define _WIN32_WINNT 0x0400", "#define _WIN32_WINNT 0x0601")
    # PATCH 5: the typelib in the project is a 32-bit one; the engine does not need it registered
    cpp = os.path.join(build_dir, "ttseng.cpp")
    patch(cpp, "_Module.RegisterServer(TRUE)", "_Module.RegisterServer(FALSE)")
    patch(cpp, "_Module.UnregisterServer(TRUE)", "_Module.UnregisterServer(FALSE)")
    return build_dir


def vs_environment(arch):
    """Return os.environ plus the variables set by vcvarsall.bat for the given arch."""
    vswhere = os.path.join(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
                           "Microsoft Visual Studio", "Installer", "vswhere.exe")
    base = [vswhere, "-latest", "-products", "*", "-property", "installationPath"]
    root = subprocess.run(base + ["-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64"],
                          capture_output=True, text=True).stdout.strip()
    if not root:
        raise SystemExit("Visual Studio with the C++ tools was not found")
    atl = subprocess.run(base + ["-requires", "Microsoft.VisualStudio.Component.VC.ATL"],
                         capture_output=True, text=True).stdout.strip()
    if not atl:
        log("ATL component missing - installing it (a few minutes)")
        setup = os.path.join(os.path.dirname(vswhere), "setup.exe")
        subprocess.run([setup, "modify", "--installPath", root, "--add",
                        "Microsoft.VisualStudio.Component.VC.ATL", "--quiet", "--norestart",
                        "--noUpdateInstaller"], check=False)
    vcvars = os.path.join(root, "VC", "Auxiliary", "Build", "vcvarsall.bat")
    out = subprocess.run('cmd /c ""%s" %s >nul && set"' % (vcvars, arch), shell=True,
                         capture_output=True, text=True).stdout
    env = dict(os.environ)
    for line in out.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            env[k] = v
    return env


def run(cmd, env, cwd, dry):
    log("> " + " ".join(cmd))
    if dry:
        return
    r = subprocess.run(cmd, env=env, cwd=cwd)
    if r.returncode != 0:
        raise SystemExit("command failed (%d): %s" % (r.returncode, cmd[0]))


def find_header(env, name):
    for d in env.get("INCLUDE", "").split(";"):
        if d and os.path.exists(os.path.join(d, name)):
            return os.path.join(d, name)
    return None


def build(arch, dry):
    build_dir = prepare(os.path.join(ROOT, "build-tmp", "sapi-" + arch))
    out_dir = os.path.join(ROOT, "build-out", "sapi")
    os.makedirs(out_dir, exist_ok=True)
    env = os.environ if dry else vs_environment("x64" if arch == "x64" else "x86")
    if not dry:
        for h in ("atlbase.h", "atlcom.h", "spddkhlp.h", "spcollec.h", "sapiddk.h"):
            p = find_header(env, h)
            log("%-12s %s" % (h, p or "NOT FOUND"))
            if not p:
                raise SystemExit("required header %s is missing (ATL component or Windows SDK)" % h)

    defs = ["NDEBUG", "WIN32", "_WINDOWS", "_MBCS", "_USRDLL", "_ATL_STATIC_REGISTRY",
            "_CRT_SECURE_NO_WARNINGS", "_CRT_NONSTDC_NO_WARNINGS", "_WINSOCK_DEPRECATED_NO_WARNINGS",
            "_WIN32_WINNT=0x0601"]
    if arch == "x64":
        defs.append("__WIN64__")
    cflags = ["cl", "/nologo", "/c", "/MT", "/O1", "/EHsc", "/W3", "/wd4244", "/wd4267", "/wd4996",
              "/wd4305", "/wd4309", "/wd4838", "/wd4018", "/wd4101", "/wd4102", "/wd4311", "/wd4302",
              "/I."] + ["/D" + d for d in defs]
    objs = []
    for name in ENGINE_SOURCES:
        run(cflags + ["/Fo%s.obj" % name, name + ".cpp"], env, build_dir, dry)
        objs.append(name + ".obj")
    for name in LIB_SOURCES:
        run(cflags + ["/Fosrc_%s.obj" % name, os.path.join("src", name + ".cpp")], env, build_dir, dry)
        objs.append("src_%s.obj" % name)
    run(["rc", "/nologo", "/l", "0x409", "/I.", "/fo", "ttseng.res", "ttseng.rc"], env, build_dir, dry)
    dll = "espeak_sapi-%s.dll" % arch
    run(["link", "/nologo", "/DLL", "/OUT:" + dll, "/DEF:ttseng.def",
         "/MACHINE:" + ("X64" if arch == "x64" else "X86")] + objs +
        ["ttseng.res", "kernel32.lib", "user32.lib", "advapi32.lib", "ole32.lib", "oleaut32.lib",
         "uuid.lib", "sapi.lib"], env, build_dir, dry)
    if not dry:
        shutil.copy2(os.path.join(build_dir, dll), os.path.join(out_dir, dll))
        log("built " + os.path.join(out_dir, dll))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--arch", choices=["x86", "x64"], required=True)
    ap.add_argument("--dry-run", action="store_true", help="prepare sources and print commands only")
    a = ap.parse_args()
    build(a.arch, a.dry_run)
