; NSIS installer for eSpeak 1.48.15 (Windows DLL build + data, optional SAPI5 voices).
; Built by tools/build-installer.sh.  WITH_SAPI includes/registers the 32-bit SAPI5 engine,
; WITH_SAPI_X64 additionally the 64-bit one.
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"

!ifndef STAGE
  !error "pass /DSTAGE=<staging dir>"
!endif

!define SAPI_CLSID "{BE985C8D-BE32-4A22-AA93-55C16A6D1D91}"
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\eSpeak1.48.15"
!define TOKENS "Software\Microsoft\Speech\Voices\Tokens"

Name "eSpeak 1.48.15"
OutFile "${STAGE}\..\setup_espeak_1.48.15.exe"
InstallDir "$PROGRAMFILES\eSpeak"
InstallDirRegKey HKLM "Software\eSpeak1.48.15" "InstallDir"
RequestExecutionLevel admin
SetCompressor /SOLID lzma

!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

!ifdef WITH_SAPI
; Writes one SAPI5 voice token into the registry view that is currently selected.
!macro SapiToken ID DISPLAY VOICENAME LCID GENDER
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}" "" "${DISPLAY}"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}" "CLSID" "${SAPI_CLSID}"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}" "Path" "$INSTDIR"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}" "VoiceName" "${VOICENAME}"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}\Attributes" "Name" "${DISPLAY}"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}\Attributes" "Gender" "${GENDER}"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}\Attributes" "Age" "Adult"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}\Attributes" "Language" "${LCID}"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}\Attributes" "Vendor" "eSpeak"
  WriteRegStr HKLM "${TOKENS}\eSpeak_${ID}\Attributes" "Version" "1.48.15"
!macroend

!macro SapiAllTokens
  !insertmacro SapiToken "fa" "eSpeak Persian" "fa" "429" "Male"
  !insertmacro SapiToken "fa-en-us" "eSpeak Persian + English (US)" "fa-en-us" "429" "Male"
  !insertmacro SapiToken "fa-pin" "eSpeak Persian (Pinglish)" "fa-pin" "429" "Male"
  !insertmacro SapiToken "en-us" "eSpeak English (US)" "en-us" "409" "Male"
  !insertmacro SapiToken "en" "eSpeak English (UK)" "en" "809" "Male"
!macroend

!macro SapiDeleteTokens
  DeleteRegKey HKLM "${TOKENS}\eSpeak_fa"
  DeleteRegKey HKLM "${TOKENS}\eSpeak_fa-en-us"
  DeleteRegKey HKLM "${TOKENS}\eSpeak_fa-pin"
  DeleteRegKey HKLM "${TOKENS}\eSpeak_en-us"
  DeleteRegKey HKLM "${TOKENS}\eSpeak_en"
!macroend
!endif

Section "eSpeak"
  SetOutPath "$INSTDIR\bin"
  ${If} ${RunningX64}
    File "/oname=espeak.dll" "${STAGE}\x64\espeak.dll"
    File "/oname=espeak-cli.exe" "${STAGE}\x64\espeak-cli.exe"
  ${Else}
    File "/oname=espeak.dll" "${STAGE}\x86\espeak.dll"
    File "/oname=espeak-cli.exe" "${STAGE}\x86\espeak-cli.exe"
  ${EndIf}

  SetOutPath "$INSTDIR\espeak-data"
  File /r "${STAGE}\espeak-data\*.*"

  SetOutPath "$INSTDIR"
  File "${STAGE}\License.txt"
  File "${STAGE}\ChangeLog.txt"
  File "${STAGE}\README-windows-build.txt"

!ifdef WITH_SAPI
  SetOutPath "$INSTDIR\sapi\x86"
  File "/oname=espeak_sapi.dll" "${STAGE}\sapi-x86\espeak_sapi.dll"
  ${If} ${RunningX64}
!ifdef WITH_SAPI_X64
    SetOutPath "$INSTDIR\sapi\x64"
    File "/oname=espeak_sapi.dll" "${STAGE}\sapi-x64\espeak_sapi.dll"
    ; 64-bit regsvr32 for the 64-bit engine
    ${DisableX64FSRedirection}
    ExecWait '"$WINDIR\System32\regsvr32.exe" /s "$INSTDIR\sapi\x64\espeak_sapi.dll"'
    ${EnableX64FSRedirection}
    SetRegView 64
    !insertmacro SapiAllTokens
!endif
    ; 32-bit regsvr32 for the 32-bit engine (used by 32-bit programs)
    ExecWait '"$WINDIR\SysWOW64\regsvr32.exe" /s "$INSTDIR\sapi\x86\espeak_sapi.dll"'
    SetRegView 32
    !insertmacro SapiAllTokens
    SetRegView 64
  ${Else}
    ExecWait '"$SYSDIR\regsvr32.exe" /s "$INSTDIR\sapi\x86\espeak_sapi.dll"'
    !insertmacro SapiAllTokens
  ${EndIf}
!endif

  WriteUninstaller "$INSTDIR\uninstall.exe"
  WriteRegStr HKLM "Software\eSpeak1.48.15" "InstallDir" "$INSTDIR"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayName" "eSpeak 1.48.15"
  WriteRegStr HKLM "${UNINST_KEY}" "DisplayVersion" "1.48.15"
  WriteRegStr HKLM "${UNINST_KEY}" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoRepair" 1

  CreateDirectory "$SMPROGRAMS\eSpeak"
  CreateShortCut "$SMPROGRAMS\eSpeak\eSpeak folder.lnk" "$INSTDIR"
  CreateShortCut "$SMPROGRAMS\eSpeak\Uninstall eSpeak.lnk" "$INSTDIR\uninstall.exe"
SectionEnd

Section "Uninstall"
!ifdef WITH_SAPI
  ${If} ${RunningX64}
!ifdef WITH_SAPI_X64
    ${DisableX64FSRedirection}
    ExecWait '"$WINDIR\System32\regsvr32.exe" /u /s "$INSTDIR\sapi\x64\espeak_sapi.dll"'
    ${EnableX64FSRedirection}
!endif
    ExecWait '"$WINDIR\SysWOW64\regsvr32.exe" /u /s "$INSTDIR\sapi\x86\espeak_sapi.dll"'
    SetRegView 64
    !insertmacro SapiDeleteTokens
    SetRegView 32
    !insertmacro SapiDeleteTokens
    SetRegView 64
  ${Else}
    ExecWait '"$SYSDIR\regsvr32.exe" /u /s "$INSTDIR\sapi\x86\espeak_sapi.dll"'
    !insertmacro SapiDeleteTokens
  ${EndIf}
  RMDir /r "$INSTDIR\sapi"
!endif
  RMDir /r "$INSTDIR\bin"
  RMDir /r "$INSTDIR\espeak-data"
  Delete "$INSTDIR\License.txt"
  Delete "$INSTDIR\ChangeLog.txt"
  Delete "$INSTDIR\README-windows-build.txt"
  Delete "$INSTDIR\uninstall.exe"
  RMDir "$INSTDIR"
  RMDir /r "$SMPROGRAMS\eSpeak"
  DeleteRegKey HKLM "Software\eSpeak1.48.15"
  DeleteRegKey HKLM "${UNINST_KEY}"
SectionEnd
